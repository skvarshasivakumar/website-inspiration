# DRY switch hover card [ Speedy CSS Tips! ⚡️]

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/dyKXmpB](https://codepen.io/jh3y/pen/dyKXmpB).

