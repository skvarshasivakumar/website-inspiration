# Personal Portfolio Website
This project is one of the results of my journey learning frontend with react.


# Preview
![screencapture-localhost-3000-2022-12-20-20_12_19](https://user-images.githubusercontent.com/73756341/208675550-16881030-8ac9-451f-9cbb-85ebc9ffca97.png)
