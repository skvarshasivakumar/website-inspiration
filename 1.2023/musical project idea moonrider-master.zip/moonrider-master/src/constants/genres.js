module.exports = [
  {name: 'Pop', row: 1, column: 1},
  {name: 'R&B', row: 1, column: 2},
  {name: 'Rap', row: 1, column: 3},
  {name: 'Rock', row: 1, column: 4},
  {name: 'Soundtrack', row: 1, column: 5},
  {name: 'Video Games', row: 1, column: 6},

  {name: 'Electronic', row: 2, column: 1},
  {name: 'Hip Hop', row: 2, column: 2},
  {name: 'House', row: 2, column: 3},
  {name: 'J-Pop', row: 2, column: 4},
  {name: 'K-Pop', row: 2, column: 5},
  {name: 'Meme', row: 2, column: 6},

  {name: 'Alternative', row: 3, column: 1},
  {name: 'Anime', row: 3, column: 2},
  {name: 'Comedy', row: 3, column: 3},
  /* {name: 'TODO', row: 3, column: 4}, */
  {name: 'Dubstep', row: 3, column: 5},
  {name: 'Dance', row: 3, column: 6}
];
