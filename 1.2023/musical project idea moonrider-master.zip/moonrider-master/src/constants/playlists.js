module.exports = [
  {name: 'favorites', author: 'You!', title: 'Your Saved Favorites'},
  {name: '3966', author: 'BeastSaber', title: 'Songs With Fantastic Flow Vol. 1'},
  {name: '3967', author: 'BeastSaber', title: 'Songs With Fantastic Flow Vol. 2'},
  {name: '3968', author: 'BeastSaber', title: 'Songs With Fantastic Flow Vol. 3'},
  {name: '4134', author: 'BeastSaber', title: 'Songs With Fantastic Flow Vol. 4'},
  {name: '4135', author: 'BeastSaber', title: 'Songs With Fantastic Flow Vol. 5'},
  {name: '7483', author: 'BeastSaber', title: 'Maps Of The Weeks'},
  {name: '4137', author: 'BeastSaber', title: "Curator's Picks of 2020"},
  {name: '4139', author: 'BeastSaber', title: "Curator's Picks of 2021"},
  {name: '11584', author: 'BeastSaber', title: "Curator's Picks of 2022"},
  {name: '4405', author: 'BeastSaber', title: 'Intro to Dance'},
  {name: '4138', author: 'BeastSaber', title: "Mom's Maps"}
];
