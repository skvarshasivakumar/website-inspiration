# react-tailwind-portfolio

+ <a href="https://www.youtube.com/watch?v=hYv6BM2fWd8">Design</a>

+ Made with tailwind

![Ekran görüntüsü 2023-01-28 221435](https://user-images.githubusercontent.com/104009655/215286744-b85473b0-22cd-4deb-9152-149cad4c90cd.png)

![Ekran görüntüsü 2023-01-28 221445](https://user-images.githubusercontent.com/104009655/215286723-3defaee7-09e9-4fc6-8ab4-4d6187ffc001.png)

![Ekran görüntüsü 2023-01-28 221901](https://user-images.githubusercontent.com/104009655/215286846-86706df7-37a1-4764-b4b7-6aafa74c2a18.png)

![Ekran görüntüsü 2023-01-28 221504](https://user-images.githubusercontent.com/104009655/215286732-3522a344-a21f-4a77-9c8f-dd72ce881288.png)
