# Hover effect (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/NWpLKPy](https://codepen.io/amit_sheen/pen/NWpLKPy).

