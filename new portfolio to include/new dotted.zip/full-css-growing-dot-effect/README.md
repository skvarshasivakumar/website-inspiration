# Full CSS growing dot effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/onediv/pen/zYEZXdz](https://codepen.io/onediv/pen/zYEZXdz).

