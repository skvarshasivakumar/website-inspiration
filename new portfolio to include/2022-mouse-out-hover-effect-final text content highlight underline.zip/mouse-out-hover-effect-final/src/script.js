// Adam is awesome. 'Nuff said.
// https://codepen.io/argyleink/pen/poEjvpd
